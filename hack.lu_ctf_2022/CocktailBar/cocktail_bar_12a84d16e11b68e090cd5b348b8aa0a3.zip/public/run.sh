#!/bin/sh
docker build -t cocktailbar . && docker run -it cocktailbar